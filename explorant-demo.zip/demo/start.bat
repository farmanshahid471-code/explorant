@echo off
REM ============================================================
REM  Explorant demo - start on Windows
REM  Requires PHP installed and on PATH (https://windows.php.net)
REM  Just double-click this file, or put the folder in Terminal and
REM  run:  php -S localhost:8090
REM ============================================================
cd /d "%~dp0"
echo Starting Explorant demo on http://localhost:8090  (Ctrl+C to stop)
echo   Login:  vakking22@gmail.com / vakking22@@
echo   Admin:  open http://localhost:8090/admin.php  (password in config.php)
echo.
php -S localhost:8090
pause
